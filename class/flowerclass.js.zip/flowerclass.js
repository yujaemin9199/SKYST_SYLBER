module.exports = class Flower {
    constructor(index, type, growth, location) {
        this.type = type;
        this.growth = growth;
        this.index = index;
        this.location = location;
    }
}